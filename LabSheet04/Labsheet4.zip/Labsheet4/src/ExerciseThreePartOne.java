import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExerciseThreePartOne {
    public static void main(String[] args) {
        // Create a byte array to write into a file
        byte[] dataToWrite = "Hello, Byte Streams!".getBytes();

        // Define the file name
        String fileName = "byte_stream_example.txt";

        try {
            // Create a FileOutputStream to write data to a file
            FileOutputStream outputStream = new FileOutputStream(fileName);

            // Write data to the file
            outputStream.write(dataToWrite);

            // Close the output stream
            outputStream.close();

            // Create a FileInputStream to read data from the file
            FileInputStream inputStream = new FileInputStream(fileName);

            // Read data from the file
            byte[] dataRead = new byte[dataToWrite.length];
            inputStream.read(dataRead);

            // Close the input stream
            inputStream.close();

            // Display the read data as a string
            System.out.println("Data read from file: " + new String(dataRead));
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
