import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ExerciseFour {
    public static void main(String[] args) {
        // Define the file name and the string to write
        String fileName = "output.txt";
        String content = "Hello, this is a string written to a file!";

        try {
            // Create a FileWriter with the specified file name
            FileWriter fileWriter = new FileWriter(fileName);

            // Wrap the FileWriter in a BufferedWriter for efficient writing
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            // Write the string to the file
            bufferedWriter.write(content);

            // Close the BufferedWriter (this will also close the FileWriter)
            bufferedWriter.close();

            System.out.println("String has been written to " + fileName);
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
