import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ExerciseFive {
    public static void main(String[] args) {
        // Define the file name
        String fileName = "my_details.txt";

        try {
            // Create a FileReader to read from the file
            FileReader fileReader = new FileReader(fileName);

            // Wrap the FileReader in a BufferedReader for efficient reading
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            System.out.println("Contents of the file:");

            // Read and print each line of the file
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }

            // Close the BufferedReader (this will also close the FileReader)
            bufferedReader.close();
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
