import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ExerciseTwoPartTwo {
    public static void main(String[] args) {
        // Create a BufferedReader object for reading from the console
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Enter a string: ");
            // Read a line of input from the console
            String input = reader.readLine();

            // Check if the input is not empty
            if (!input.isEmpty()) {
                // Display the string entered by the user
                System.out.println("You entered: " + input);
            } else {
                System.out.println("No input provided.");
            }
        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
        } finally {
            try {
                // Close the BufferedReader when done
                reader.close();
            } catch (IOException e) {
                System.err.println("Error closing BufferedReader: " + e.getMessage());
            }
        }
    }
}
