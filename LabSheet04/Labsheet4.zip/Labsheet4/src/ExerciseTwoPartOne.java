import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ExerciseTwoPartOne {
    public static void main(String[] args) {
        // Create a BufferedReader object for reading from the console
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Enter a character: ");
            // Read a line of input from the console
            String input = reader.readLine();

            // Check if the input is not empty
            if (!input.isEmpty()) {
                // Get the first character from the input
                char character = input.charAt(0);

                // Display the character
                System.out.println("You entered: " + character);
            } else {
                System.out.println("No input provided.");
            }
        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
        } finally {
            try {
                // Close the BufferedReader when done
                reader.close();
            } catch (IOException e) {
                System.err.println("Error closing BufferedReader: " + e.getMessage());
            }
        }
    }
}
