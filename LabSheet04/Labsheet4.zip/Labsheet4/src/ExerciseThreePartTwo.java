import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ExerciseThreePartTwo {
    public static void main(String[] args) {
        // Define the file name
        String fileName = "character_stream_example.txt";

        try {
            // Create a FileWriter to write character data to a file
            FileWriter writer = new FileWriter(fileName);

            // Write a string to the file
            writer.write("Hello, Character Streams!");

            // Close the writer
            writer.close();

            // Create a FileReader to read character data from the file
            FileReader reader = new FileReader(fileName);

            // Read data from the file
            char[] dataRead = new char[50];
            int bytesRead = reader.read(dataRead);

            // Close the reader
            reader.close();

            // Display the read data as a string
            System.out.println("Data read from file: " + new String(dataRead, 0, bytesRead));
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
